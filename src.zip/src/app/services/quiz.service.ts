import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Question } from '../models/question.model';
import { User } from '../models/user.model';

@Injectable({ providedIn: 'root' })
export class QuizService {
  private questions: Question[] = [];
  private currentQuestionIndex = new BehaviorSubject<number>(0);
  private participants = new Map<string, User>();

  setQuestions(qs: Question[]) {
    this.questions = qs;
  }

  getQuestions() {
    return this.questions;
  }

  getCurrentQuestion() {
    return this.questions[this.currentQuestionIndex.value];
  }

  getCurrentIndex() {
    return this.currentQuestionIndex.asObservable();
  }

  nextQuestion() {
    const nextIndex = this.currentQuestionIndex.value + 1;
    if (nextIndex < this.questions.length) {
      this.currentQuestionIndex.next(nextIndex);
    }
  }

  addParticipant(user: User) {
    this.participants.set(user.id, user);
  }

  submitAnswer(userId: string, answerIndex: number) {
    const user = this.participants.get(userId);
    const q = this.getCurrentQuestion();
    if (!user || !q) return;

    user.answers.push(answerIndex);
    if (answerIndex === q.correctIndex) {
      user.score += 1;
    }
  }

  getLeaderboard(): User[] {
    return Array.from(this.participants.values()).sort((a, b) => b.score - a.score);
  }
}
