import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AdminComponent } from './admin/admin.component';
import { JoinComponent } from './participant/join/join.component';
import { QuizComponent } from './quiz.component';
import { ResultComponent } from './participant/result/result.component';

const routes: Routes = [
  { path: 'admin', component: AdminComponent },
  { path: 'join', component: JoinComponent },
  { path: 'quiz', component: QuizComponent },
  { path: 'result', component: ResultComponent },
  { path: '', redirectTo: '/join', pathMatch: 'full' },
  { path: '**', redirectTo: '/join' } // fallback route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
