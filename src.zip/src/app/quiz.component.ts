import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {

  questions = [
    {
      text: 'Question 1 ?',
      options: ['Réponse A', 'Réponse B', 'Réponse C', 'Réponse D'],
      correctIndex: 0
    },
    // ... 19 autres questions ici
  ];

  currentQuestionIndex = 0;
  selectedAnswerIndex: number | null = null;

  constructor() { }

  ngOnInit(): void {
    // init code
  }

  selectAnswer(index: number) {
    this.selectedAnswerIndex = index;
  }

  nextQuestion() {
    this.currentQuestionIndex++;
    this.selectedAnswerIndex = null;
  }

}
