import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { QuizService } from '../../services/quiz.service';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-join',
  templateUrl: './join.component.html',
  styleUrls: ['./join.component.css']  // optionnel
})
export class JoinComponent {
  name: string = '';

  constructor(private quizService: QuizService, private router: Router) {}

  join() {
    if (!this.name.trim()) return; // sécuriser entrée vide

    const user: User = {
      id: crypto.randomUUID(),
      name: this.name.trim(),
      score: 0,
      answers: [],
    };

    this.quizService.addParticipant(user);
    localStorage.setItem('userId', user.id);
    this.router.navigate(['/quiz']);
  }
}
