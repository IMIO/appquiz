import { Component } from '@angular/core';

@Component({
  selector: 'app-participant',
  imports: [],
  templateUrl: './participant.html',
  styleUrl: './participant.css'
})
export class Participant {

}
