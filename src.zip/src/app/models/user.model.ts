export interface User {
  id: string;
  name: string;
  score: number;
  answers: number[];        // index des réponses données
}